# Pixel Icons

![banner](banner.png] 

Pixel Icons is an Acode icon plugin featuring 8x8 pixel art icons drawn using the [Duel](https://lospec.com/palette-list/duel) color palette.

# Credits

This project uses the [Material Icons](https://github.com/sebastianjnuwu/acode-plugins/tree/acode/packages/material-icons) plugin as a base to provide all the styling functionality, and only the plugin assets where changed.
