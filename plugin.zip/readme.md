# Pixel Icons

![Banner](https://raw.githubusercontent.com/The-Nice-One/acode-pixel-icons/refs/heads/main/banner.png)

An Acode icon plugin featuring 8x8 pixel art icons drawn using the [Duel](https://lospec.com/palette-list/duel) color palette.

# Credits

This plugin uses the [Material Icons](https://github.com/sebastianjnuwu/acode-plugins/tree/acode/packages/material-icons) plugin as a base to provide all the styling functionality, and only the plugin assets where changed.
